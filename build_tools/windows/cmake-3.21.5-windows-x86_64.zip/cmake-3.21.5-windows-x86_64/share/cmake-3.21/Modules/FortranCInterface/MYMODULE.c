void MYMODULE(void)
{
}
