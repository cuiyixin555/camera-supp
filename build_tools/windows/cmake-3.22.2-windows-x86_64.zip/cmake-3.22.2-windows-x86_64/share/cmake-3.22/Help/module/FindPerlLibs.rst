.. cmake-module:: ../../Modules/FindPerlLibs.cmake
