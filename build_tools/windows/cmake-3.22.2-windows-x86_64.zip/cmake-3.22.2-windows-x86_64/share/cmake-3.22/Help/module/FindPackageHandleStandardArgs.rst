.. cmake-module:: ../../Modules/FindPackageHandleStandardArgs.cmake
