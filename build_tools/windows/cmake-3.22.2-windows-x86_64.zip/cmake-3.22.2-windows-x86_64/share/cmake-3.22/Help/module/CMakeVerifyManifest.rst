.. cmake-module:: ../../Modules/CMakeVerifyManifest.cmake
