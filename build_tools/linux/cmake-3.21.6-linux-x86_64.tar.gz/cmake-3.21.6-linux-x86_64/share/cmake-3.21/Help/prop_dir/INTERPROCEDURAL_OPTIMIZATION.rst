INTERPROCEDURAL_OPTIMIZATION
----------------------------

Enable interprocedural optimization for targets in a directory.

If set to true, enables interprocedural optimizations if they are
known to be supported by the compiler.
